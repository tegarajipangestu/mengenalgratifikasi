<footer>
  <div class="well">
    <div class="container">
      @ Easy Development
    </div>
  </div>
</footer>